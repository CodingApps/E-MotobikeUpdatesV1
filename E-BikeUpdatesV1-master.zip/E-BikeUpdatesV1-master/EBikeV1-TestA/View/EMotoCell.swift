//
//  EMotoCell.swift
//  EBikeV1-TestA
//
//  Created by Rick Mc on 9/13/18.
//  Copyright © 2018 Rick Mc. All rights reserved.
//

import UIKit

internal class emotoCell : UITableViewCell {

@IBOutlet weak var textLine: UIView!
@IBOutlet weak var imageMoto: UIImageView!
        
}
    

