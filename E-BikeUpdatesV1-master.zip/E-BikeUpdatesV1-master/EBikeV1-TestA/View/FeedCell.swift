//
//  FeedCell.swift
//  EBikeV1-TestA
//
//  Created 9/5/18.
//

import UIKit

internal class feedCell : UITableViewCell {
   
    @IBOutlet var Title: UILabel!

}
