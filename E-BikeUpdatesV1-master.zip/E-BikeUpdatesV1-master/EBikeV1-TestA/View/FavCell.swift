//
//  FavCell.swift
//  EBikeV1-TestA
//
//  Created by Rick Mc on 9/15/18.
//  Copyright © 2018 Rick Mc. All rights reserved.
//

import UIKit

internal class favCell : UITableViewCell {
    
    @IBOutlet weak var favCell: UIView!
    
}
